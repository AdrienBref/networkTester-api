package com.sunt.NetworkTester.DTO;

import lombok.*;

@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class EmailResponseDTO {
    private String id;
    private String email;
}
