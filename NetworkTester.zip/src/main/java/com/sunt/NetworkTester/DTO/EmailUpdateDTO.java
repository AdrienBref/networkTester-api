package com.sunt.NetworkTester.DTO;

public class EmailUpdateDTO {
}
