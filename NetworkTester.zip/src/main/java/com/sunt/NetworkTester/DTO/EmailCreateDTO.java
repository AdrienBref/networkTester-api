package com.sunt.NetworkTester.DTO;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class EmailCreateDTO {
    private String email;
}
