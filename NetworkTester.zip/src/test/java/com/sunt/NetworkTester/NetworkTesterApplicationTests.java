package com.sunt.NetworkTester;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NetworkTesterApplicationTests {

	@Test
	void contextLoads() {
	}

}
